# swagger-typescript-api

# templates/base

This templates use both for multiple api files and single api file

path prefix `@base`
