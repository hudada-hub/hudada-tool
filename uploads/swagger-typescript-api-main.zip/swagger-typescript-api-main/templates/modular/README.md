# swagger-typescript-api

# templates/modular

This templates use for multiple api files (`--modular` option)

path prefix `@modular`
